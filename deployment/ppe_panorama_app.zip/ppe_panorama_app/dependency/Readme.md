# Export Yolov5 to ONNX for TRT7

Run the following code. This code is based on https://github.com/ultralytics/yolov5/blob/master/export.py

```
python export_trt7_onnx.py --weights yolov5s.pt
```